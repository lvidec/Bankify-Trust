export class User{

  _id: any;
  username: string;
  email: string;
  password: string;
  repeatedPassword?: string;
  balance: number;
  level: number;

}
